import boto3
import os
import botocore
from botocore import UNSIGNED
from botocore.client import Config
import json
import logging

from datetime import datetime, timedelta

log = logging.getLogger()

s3 = boto3.client('s3')

OPENAQ_BUCKET = 'openaq-fetches'
DATA_PREFIX = 'realtime-gzipped'
OUTPUT_BUCKET = os.environ['TARGET_BUCKET']
TEMP_FOLDER_TEMPLATE = 'openaqdata/{}'

# look for all files from previous day
prev_day = datetime.utcnow() - timedelta(days=1)
prev_day = prev_day.strftime('%Y-%m-%d')
prefix = '{}/{}/'.format(DATA_PREFIX, prev_day)

def get_file_inventory():
    try:
        response = s3.list_objects_v2(Bucket=OPENAQ_BUCKET, Prefix=prefix)
        if 'Contents' in response:
            file_names = [item['Key'] for item in response['Contents']]
        else:
            file_names = []
    except Exception as e:
        print('Unable to list OpenAQ files')
        raise
    return file_names


def main(event, context):
    file_names = get_file_inventory()
    json_object = json.dumps({ "previousDayFiles": file_names }, indent = 4)
    file_name = "openaqdata_" + prev_day + ".json"
    
    with open("/tmp/" + file_name, "w") as outfile:
        outfile.write(json_object)

    # upload to target S3 bucket
    try:
        response = s3.upload_file(
            "/tmp/" + file_name,
            OUTPUT_BUCKET,
            TEMP_FOLDER_TEMPLATE.format(file_name))
        log.info("Uploaded file list to s3://{}/".format(OUTPUT_BUCKET) + TEMP_FOLDER_TEMPLATE.format(file_name))
    except botocore.exceptions.ClientError as e:
        log.error(f'Unable to upload: {file_name}')
        log.debug(e)
        raise

    return { 
        "result": "Successful",
        "previousDayFiles": file_names 
    }