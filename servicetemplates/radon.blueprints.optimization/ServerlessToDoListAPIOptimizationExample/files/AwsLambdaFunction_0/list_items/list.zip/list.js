'use strict';

const AWS = require('aws-sdk');
const dynamoDb = new AWS.DynamoDB.DocumentClient();

module.exports.handler = (event, context, callback) => {
    let timestamps = new Array(4);
    timestamps[0] = Date.now();
    const headers = {
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Credentials": "true",
        "Content-Type": "application/json",
        "X-Requested-With": "*",
        "Access-Control-Allow-Headers": 'Content-Type,X-Amz-Date,Authorization,x-api-key,x-requested-with,Cache-Control',
    };
    
    const params = {
        TableName: process.env.TODOS_TABLE
    };

    timestamps[1] = Date.now();
    dynamoDb.scan(params, (error, result) => {
        timestamps[2] = Date.now();
        if (error) {
            console.error(error);
            callback(null, {
                headers: headers,
                statusCode: error.statusCode || 501,
                body: JSON.stringify('Couldn\'t fetch the todos.'),
            });
            return;
        }

        const response = {
            statusCode: 200,
            headers: headers,
            body: JSON.stringify(result.Items)
        };
        timestamps[3] = Date.now();
        console.log(timestamps);
        callback(null, response);
    });
};